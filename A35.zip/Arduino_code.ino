/* * Project: Heat Index Monitor 
 * Features: Dual Sensor Logging (Temp + Humidity)
 */

#include "DHT.h" // Required library for DHT sensors

#define DHTPIN 2     // Digital pin connected to the DHT sensor
#define DHTTYPE DHT11 // Define the sensor type

class EnvironmentalSensor {
  private:
    int thermistorPin;
    DHT dht;

  public:
    EnvironmentalSensor(int tPin, int dPin) : dht(dPin, DHTTYPE) {
      thermistorPin = tPin;
    }

    void begin() {
      dht.begin();
    }

    float getTemperature() {
      // Calculate Temp from Kit Thermistor
      int val = analogRead(thermistorPin);
      float resistance = 10000.0 / (1023.0 / val - 1);
      float tempK = 1.0 / (log(resistance / 10000.0) / 3950.0 + 1.0 / 298.15);
      return tempK - 273.15;
    }

    float getHumidity() {
      // Read humidity from the DHT sensor
      float h = dht.readHumidity();
      return (isnan(h)) ? 0.0 : h; // Error handling if sensor is missing
    }
};

EnvironmentalSensor myStation(A0, DHTPIN);

void setup() {
  Serial.begin(9600);
  myStation.begin();
  [span_2](start_span)// Header for CSV logging[span_2](end_span)
  Serial.println("Timestamp_ms,Temperature_C,Humidity_Pct");
}

void loop() {
  Serial.print(millis());
  Serial.print(",");
  Serial.print(myStation.getTemperature());
  Serial.print(",");
  Serial.println(myStation.getHumidity());

  delay(2000); [span_3](start_span)// Data logging interval[span_3](end_span)
}